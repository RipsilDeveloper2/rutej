
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Ruthej Clothing</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Raleway:400,200,600,800,700,500,300,100,900' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Arimo:400,700,700italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="css/component.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="New Fashions Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" 
		/>		
<script src="js/jquery.min.js"></script>
<script src="js/simpleCart.min.js"> </script>
<!-- start menu -->
<link href="css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="js/megamenu.js"></script>
<script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
<!-- start menu -->
</head>
<body>
<!--header-->
<?php include("header.php");?>
<div class="about">
	 <div class="container">
			<ol class="breadcrumb">
		  <li><a href="index.html">Home</a></li>
		  <li class="active">About</li>
		 </ol>
		 <h2>ABOUT US</h2>
		 <div class="about-sec">
			 <div class="about-pic"><img src="images/a1.jpg" class="img-responsive" alt=""/></div>
			 <div class="about-info">
				 <p style="text-align: justify;"><b style="font-size: 20px">About Us</b><br>
				 	Rutej Clothing Co. is promoted by persons who are pioneers in textiles and apparels industry  with at least 6 decades of experience in the fashion world. 
					As the Promoters are well researched and experienced  with the latest trends and demand of the fashion industry, and as Kurtis, Bottoms, Mix and Match are quickly replacing the traditional Sari and Salwar Kameez in a woman’s everyday wardrobe, Hence Our company has decided to tap women Apparels market with the launch of our Brand "JHUMKOO"
					We value the Integrity, Team work, Customer Service, Learning and Development, Ownership and commitment to maximize growth within an ethical and socially responsible environment. <br>
					As the significance of quality apparel lies in its raw material and  designs, our company  believes in picking best of the fabrics which is picked by the expert R&D team and designed by Our own Highly Artistic Designers who blend modern pattern and traditional designs Producing innovative and fashionable attire and with no compromises on choosing fabrics as quality is the Buzzword at Rutej Clothing Co.
					Due to our economic production It enables our product to carry very competitive price tags but no compromise takes place on design and quality of fabric because our motto is "value for money'' <br>
					The company is very well aware that today customer expectation is very demanding and the market is change from “Customer Satisfaction to Customer Delight”, hence our aim is also to build long term relation with our customers by offering them latest designs, high product quality and competitive priced products. The company is committed to have its PAN India presence in near future and we believe that you will be delightful and surprised to see some of our latest innovation in both concept and designs  and invite you to call for an appointment to visit our sales office and will be happy to arrange samplings for you at your convenience.
					<br><br>
					<b style="font-size: 20px">Our Mission: </b> <br>
					To make the company leading apparel brand locally as well as globally.<br><br>
					<b style="font-size: 20px">Our Vision</b><br>
					Our vision is To be the inspired solution for branded clothing & to set the standard for quality, delivery and personalized friendly service in the apparel manufacturing industry.
					Lifestyle merchandising is our business and our passion. The goal for our brands is to build a strong
					emotional bond with the customer. To do this we must build lifestyle environments that appeal
					emotionally, and offer fashion correct products on a timely basis. Our customers are the reason and
					inspiration for everything we do.</p>
				 
			 </div>
			 <div class="clearfix"></div>
		 </div>
		 <!--<h3>OUR SPECIALS</h3>
		 <div class="about-grids">
			 <div class="col-md-3 about-grid">
				 <img src="images/ab1.jpg" class="img-responsive" alt=""/>
				 <a href="blog-single.html"><h4>Kurtis & Kurtas</h4></a>
				 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, recusandae, minima deserunt pariatur illo eos doloremque
				 Asperiores modi temporibus consequuntur tempore quibusdam!</p>
			 </div>
			 <div class="col-md-3 about-grid">
				 <img src="images/ab2.jpg" class="img-responsive" alt=""/>
				 <a href="blog-single.html"><h4>Salwars</h4></a>
				 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, recusandae, minima deserunt pariatur illo eos doloremque 
				 Asperiores modi temporibus consequuntur tempore quibusdam!</p>
			 </div>
			 <div class="col-md-3 about-grid pot-2">
				 <img src="images/ab3.jpg" class="img-responsive" alt=""/>
				 <a href="blog-single.html"><h4>Desi Look</h4></a>
				 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, recusandae, minima deserunt pariatur illo eos doloremque
				 Asperiores modi temporibus consequuntur tempore quibusdam!</p>
			 </div>
			 <div class="col-md-3 about-grid pot-1">
				 <img src="images/ab4.jpg" class="img-responsive" alt=""/>
				 <a href="blog-single.html"><h4>Designersaree</h4></a>
				 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, recusandae, minima deserunt pariatur illo eos doloremque 
				 Asperiores modi temporibus consequuntur tempore quibusdam!</p>
			 </div>
			 <div class="clearfix"></div>
			 <div class="bottom-grids">
			 <div class="col-md-3 about-grid flwr">
				 <img src="images/ab5.jpg" class="img-responsive" alt=""/>
				 <a href="blog-single.html"><h4>NEWLOOK</h4></a>
				 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, recusandae, minima deserunt pariatur illo eos doloremque
				 Asperiores modi temporibus consequuntur tempore quibusdam!</p>
			 </div>
			 <div class="col-md-3 about-grid flwr">
				 <img src="images/ab6.jpg" class="img-responsive" alt=""/>
				 <a href="blog-single.html"><h4>Meriea</h4></a>
				 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, recusandae, minima deserunt pariatur illo eos doloremque 
				 Asperiores modi temporibus consequuntur tempore quibusdam!</p>
			 </div>
			 <div class="col-md-3 about-grid flwr pot-2">
				 <img src="images/ab7.jpg" class="img-responsive" alt=""/>
				 <a href="blog-single.html"><h4>Woolen Shurg</h4></a>
				 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, recusandae, minima deserunt pariatur illo eos doloremque
				 Asperiores modi temporibus consequuntur tempore quibusdam!</p>
			 </div>
			 <div class="col-md-3 about-grid flwr pot-1">
				 <img src="images/ab8.jpg" class="img-responsive" alt=""/>
				 <a href="blog-single.html"><h4>Black Shurg</h4></a>
				 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Natus, recusandae, minima deserunt pariatur illo eos doloremque 
				 Asperiores modi temporibus consequuntur tempore quibusdam!</p>
			 </div>
			 <div class="clearfix"></div>
			 </div>
		 </div>-->
	 </div>
</div>

<?php include("footer.php");?>

</body>
</html>