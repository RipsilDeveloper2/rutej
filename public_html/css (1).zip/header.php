<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="header2 text-center">
	 <div class="container">
	     <div class="main-header">
			  <div class="carting">
				 <!--<ul><li><a href="login.html"> LOGIN</a></li></ul>  -->
				 </div>
			 <div class="logo">
				 <a href="index.php"><img src="images/logo1.jpg"></a>
			  </div>			  
			 <div class="box_1">				 
				 
			 
			 </div>
			 
			 <div class="clearfix"></div>
		 </div>
				
				<!-- start header menu -->
		<ul class="megamenu skyblue">
			<li class="active grid"><a class="color1" href="index.php">Home</a></li>			
			<li class="grid"><a href="shop.php">PRODUCTS</a>
			<div class="megapanel">
					<div class="row">
						<div class="col1">
							<div class="h_nav">
								
								<ul>
									<li><a href="shop.php">Kurti</a></li>
									
								</ul>	
							</div>
							<div class="h_nav">
								
								<ul>
									<li><a href="shop2.php">Plazo</a></li>
									
								</ul>	
							</div>									
						</div>
						
					</div>
					
    				</div>
    		</li>		
			 <li class="grid"><a href="about.php">ABOUT US</a></li>				
				<li><a href="contact.php">CONTACT</a>
				
				</li>			
				
				</ul> 			 
			  <div class="clearfix"></div>			   	
	 </div>
</div>
<!--header//-->
</body>
</html>